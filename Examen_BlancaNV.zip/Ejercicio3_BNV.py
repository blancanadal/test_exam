import paho.mqtt.client as mqtt # Import the MQTT library
import time # The time library is useful for delays

broker_port = 1885
broker_ip_address = '10.8.42.100'
air_topic   = 'LSE/instalaciones/despachos/5/aire'
temp_topic  = 'LSE/instalaciones/despachos/5/temperatura'
hum_topic   = 'LSE/instalaciones/despachos/5/humedad'
light_topic = 'LSE/instalaciones/despachos/5/luz'
list_air = []
list_temp = []
list_hum = []
list_light = []

pub_topic = 'LSE/trabajadores/blanca.nadal@alumnos.upm.es/alerta'


# Function that returns the avg when samples at least 5 or the message
def meanCalc (list, message):
    list.append(float(message))
    if len(list) == 6:
        list.pop(0)
        avg = sum(list)/len(list)
        return avg                      
    else:
        return message

# Our "on message" event
def messageFunction (client, userdata, message):
    messg = str(message.payload.decode("utf-8"))
    if (message.topic == air_topic):
        print(messg)
        air = (meanCalc(list_air,messg))
        print(air)
        if (float(air) > 1000):
            alerta = 'aire'
            ourClient.publish(pub_topic, pub_topic +'{\”' + alerta + '\"}') # Publish message to MQTT broker
    if (message.topic == temp_topic):
        print(messg)
        temp = meanCalc(list_temp, messg)
        if (20 > float(temp) > 25):
            alerta = 'temperatura'
            ourClient.publish(pub_topic, pub_topic +'{\”' + alerta + '\"}') # Publish message to MQTT broker
    if (message.topic == hum_topic):
        print(messg)
        hum = meanCalc(list_hum, messg)
        if (30 > float(hum) > 60):
            alerta = 'humedad'
            ourClient.publish(pub_topic, pub_topic +'{\”' + alerta + '\"}') # Publish message to MQTT broker            
    if (message.topic == light_topic):
        print(messg)
        light = meanCalc(list_light, messg)
        if (300 > float(light) > 500):
            alerta = 'luz'
            ourClient.publish(pub_topic, pub_topic +'{\”' + alerta + '\"}') # Publish message to MQTT broker
    if (message.topic == pub_topic):
         print(messg)           # Flag to check the alarm notification

ourClient = mqtt.Client("BLANCA") # Create a MQTT client object
ourClient.connect(broker_ip_address, broker_port) # Connect to the test MQTT broker
ourClient.subscribe(air_topic) # Subscribe to the topic
ourClient.subscribe(temp_topic) # Subscribe to the topic
ourClient.subscribe(hum_topic) # Subscribe to the topic
ourClient.subscribe(light_topic) # Subscribe to the topic
ourClient.subscribe(pub_topic) # Subscribe to the topic
ourClient.loop_start() # Start the MQTT client

# Main program loop
while(1):
    ourClient.on_message = messageFunction # Attach the messageFunction to subscription
    time.sleep(3) # Sleep for 3 seconds
