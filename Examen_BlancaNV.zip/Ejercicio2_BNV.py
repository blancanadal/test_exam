import paho.mqtt.client as mqtt # Import the MQTT library
import time # The time library is useful for delays

broker_port = 1885
broker_ip_address = '10.8.42.100'
desk_number = 21
list_light = []

# Our "on message" event
def messageFunction (client, userdata, message):
    client_topic = ' '
    if (message.topic == 'LSE/instalaciones/despachos/21/email_ocupante'):
        UPM_email = str(message.payload.decode("utf-8"))
        print(UPM_email)
        client_topic = 'LSE/trabajadores/'+UPM_email+'/promedios/luz'
    if (message.topic == "LSE/instalaciones/despachos/21/luz"):
        new_data = str(message.payload.decode("utf-8"))
        list_light.append(float(new_data))
        if len(list_light) == 6:
            list_light.pop(0)
            avg = sum(list_light)/len(list_light)
            print(avg)
            ourClient.publish(client_topic, client_topic +'{\"message\": \"' + str(avg) + '\"}') # Publish message to MQTT broker


ourClient = mqtt.Client("BLANCA") # Create a MQTT client object
ourClient.connect(broker_ip_address, broker_port) # Connect to the test MQTT broker
ourClient.subscribe('LSE/instalaciones/despachos/21/email_ocupante') # Subscribe to the topic
ourClient.subscribe('LSE/instalaciones/despachos/21/luz') # Subscribe to the topic
ourClient.loop_start() # Start the MQTT client

# Main program loop
while(1):
    ourClient.on_message = messageFunction # Attach the messageFunction to subscription
    time.sleep(3) # Sleep for 3 seconds