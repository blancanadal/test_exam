import paho.mqtt.client as mqtt # Import the MQTT library
import time # The time library is useful for delays

broker_port = 1885
broker_ip_address = '10.8.42.100'
UPM_email = 'blanca.nadal@alumnos.upm.es'

# Our "on message" event
def messageFunction (client, userdata, message):
    desk_number = '?'
    messg = str(message.payload.decode("utf-8"))
    #print(messg)
    if messg == UPM_email:
        topic_desk = message.topic.split("/") 
        desk_number = topic_desk[3] 
        print(desk_number)
        ourClient.subscribe('LSE/instalaciones/despachos/'+desk_number+'/temperatura')
    elif message.topic == 'LSE/instalaciones/despachos/'+desk_number+'/temperatura':
            temp = messg
            print(temp)

ourClient = mqtt.Client("BLANCA") # Create a MQTT client object
ourClient.connect(broker_ip_address, broker_port) # Connect to the test MQTT broker
ourClient.subscribe('LSE/instalaciones/despachos/+/email_ocupante') # Subscribe to the topic Hour
ourClient.loop_start() # Start the MQTT client

# Main program loop
while(1):
    ourClient.on_message = messageFunction # Attach the messageFunction to subscription
    time.sleep(3) # Sleep for 3 seconds
